(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-9f85946e.js")
    );
  })().catch(console.error);

})();
