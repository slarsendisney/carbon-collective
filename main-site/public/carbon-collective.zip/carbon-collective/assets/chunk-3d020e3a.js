const c=["carbon-collective.vercel.app","carboncollective.club","www.carboncollective.club","localhost"],o={verfiedDomains:c,bgColor:"#93c5fd"};export{o as c};
