(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-c79b3d5d.js")
    );
  })().catch(console.error);

})();
