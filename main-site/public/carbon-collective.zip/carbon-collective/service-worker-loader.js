import './assets/chunk-d5c96e9a.js';
